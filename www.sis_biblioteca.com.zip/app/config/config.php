<?php
/**
 * Created by PhpStorm.
 * User: HILARI
 * Date: 10/12/2019
 * Time: 20:59
 */


//localmente
define('BD_SERVIDOR','localhost');
define('BD_USUARIO','root');
define('BD_PASSWORD','');
define('BD_SISTEMA','bd_sis_biblioteca');

//servidor
/*
define('BD_SERVIDOR','localhost');
define('BD_USUARIO','root');
define('BD_PASSWORD','');
define('BD_SISTEMA','bd_sis_biblioteca');
*/

//localmente
$URL = "http://localhost/www.sis_biblioteca.com";

//servidor
//$URL = "http://www.sis_biblioteca.com";


date_default_timezone_set("America/Caracas");
$fechaHora = date('Y-m-d H:i:s');
$estado_del_registro = "1";
